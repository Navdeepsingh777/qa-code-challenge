const reporter = require("cucumber-html-reporter");
const options = {
  theme: "bootstrap",
  jsonFile: "tests/reports/cucumber-report.json",
  output: "tests/reports/cucumber-report.html",
  reportSuiteAsScenarios: true,
  launchReport: true,
  storeScreenshots: true,
  screenshotsDirectory: "tests/reports/screenshots",
  metadata: {
    "App Version": "0.1.0",
    "Test Environment": "Local",
    "Browser": "Chromium",
    "Platform": process.platform,
  }
};
reporter.generate(options);
