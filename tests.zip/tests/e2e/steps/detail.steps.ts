import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { HomePage } from "../pages/HomePage.ts";
import { DetailPage } from "../pages/DetailPage.ts";
import { CustomWorld } from "../support/world.ts";

When("I click on the first Pokémon", async function (this: CustomWorld) {
  const homePage = new HomePage(this.page);
  await homePage.clickFirstPokemon();
});

Then("I should see the detail page with a name and sprite", async function (this: CustomWorld) {
  const detailPage = new DetailPage(this.page);
  await detailPage.waitForDetailLoaded();

  const name = await detailPage.getPokemonName();
  expect(name).not.toBe("");

  const spriteVisible = await detailPage.isSpriteVisible();
  expect(spriteVisible).toBeTruthy();
});
