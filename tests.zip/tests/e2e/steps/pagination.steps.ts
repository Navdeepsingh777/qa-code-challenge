import { Given, When, Then, setDefaultTimeout } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { HomePage } from "../pages/HomePage.ts";
import { CustomWorld } from "../support/world.ts";

setDefaultTimeout(60 * 1000); // allow 60 seconds per step

let firstPokemonName: string;



When("I click on the {string} button", async function (this: CustomWorld, button: string) {
  const homePage = new HomePage(this.page);
  if (button === "Next") {
    await homePage.clickNext();
  } else if (button === "Prev") {
    await homePage.clickPrev();
  }
});

Then("I should see a different list of Pokémon", async function (this: CustomWorld) {
  const homePage = new HomePage(this.page);
  const newFirstPokemonName = await homePage.getFirstPokemonName();  // ✅ use Page Object
  expect(newFirstPokemonName).not.toBe(firstPokemonName);
});
