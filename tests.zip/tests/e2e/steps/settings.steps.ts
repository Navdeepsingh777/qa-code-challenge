import { When, Then } from "@cucumber/cucumber";
import { expect } from "@playwright/test";
import { CustomWorld } from "../support/world.ts";
import { SettingsPage } from "../pages/SettingsPage.ts";
import { DetailPage } from "../pages/DetailPage.ts";

When("I navigate to Settings", async function (this: CustomWorld) {
  const settings = new SettingsPage(this.page);
  await settings.goTo();
});

When("I change the theme to {string}", async function (this: CustomWorld, theme: string) {
  const settings = new SettingsPage(this.page);
  await settings.changeTheme(theme);
});

Then("the theme should be set to {string}", async function (this: CustomWorld, theme: string) {
  const settings = new SettingsPage(this.page);
  const selected = await settings.getSelectedTheme();
  expect(selected).toBe(theme);
});

When("I change the page size to {int}", async function (this: CustomWorld, size: number) {
  const settings = new SettingsPage(this.page);
  await settings.changePageSize(size);
});

Then("the page size should be set to {int}", async function (this: CustomWorld, size: number) {
  const settings = new SettingsPage(this.page);
  const value = await settings.getPageSize();
  expect(value).toBe(size);
});

When("I uncheck the first three detail fields", async function (this: CustomWorld) {
  const settings = new SettingsPage(this.page);
  await settings.uncheckFirstThreeDetailFields();
});

Then("the first three detail fields should not be selected", async function (this: CustomWorld) {
  const settings = new SettingsPage(this.page);
  const states = await settings.getCheckedStates();
  expect(states[0]).toBe(false);
  expect(states[1]).toBe(false);
  expect(states[2]).toBe(false);
});

When("I return to the home page", async function (this: CustomWorld) {
  await this.page.click("text=Home");
  await this.page.waitForURL("**/");
});

When("I click on the first Pokémon card", async function (this: CustomWorld) {
  await this.page.locator("a[href^='/pokemon/']").first().click();
  const detail = new DetailPage(this.page);
  await detail.waitForDetailLoaded();
});

Then("I should see fewer details on the Pokémon detail page", async function (this: CustomWorld) {
  const detail = new DetailPage(this.page);
  const sections = await detail.getVisibleDetailSections();

  expect(sections).not.toContain("Types");
  expect(sections).not.toContain("Abilities");
  expect(sections).not.toContain("Height / Weight");

  expect(sections).toContain("Stats");
  expect(sections).toContain("Description");
});
