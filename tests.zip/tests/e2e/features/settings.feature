Feature: Settings Page

  Scenario: Change theme to Dark
    Given I open the Pokédex home page
    When I navigate to Settings
    And I change the theme to "Dark"
    Then the theme should be set to "Dark"

  Scenario: Change page size to 5
    Given I open the Pokédex home page
    When I navigate to Settings
    And I change the page size to 5
    Then the page size should be set to 5

  Scenario: Uncheck first three detail fields
    Given I open the Pokédex home page
    When I navigate to Settings
    And I uncheck the first three detail fields
    Then the first three detail fields should not be selected
    When I return to the home page
    And I click on the first Pokémon card
    Then I should see fewer details on the Pokémon detail page