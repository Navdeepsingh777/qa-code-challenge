Feature: Pokémon Detail Page
  Scenario: Open first Pokémon detail page
    Given I open the Pokédex home page
    When I click on the first Pokémon
    Then I should see the detail page with a name and sprite
