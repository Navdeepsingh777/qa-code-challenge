Feature: Pokemon Pagination
  Scenario: Navigate to the next page
    Given I open the Pokédex home page
    When I click on the "Next" button
    Then I should see a different list of Pokémon
