import type { Page } from "@playwright/test";

export class DetailPage {
  readonly page: Page;

  constructor(page: Page) {
    this.page = page;
  }

  async waitForDetailLoaded() {
    await this.page.locator("h1, .pokemon-name").first().waitFor({ timeout: 10000 });
    await this.page.locator("img, .pokemon-sprite img").first().waitFor({ timeout: 10000 });
  }

  async getPokemonName(): Promise<string> {
    return this.page.locator("h1, .pokemon-name").first().innerText();
  }

  async isSpriteVisible(): Promise<boolean> {
    return this.page.locator("img, .pokemon-sprite img").first().isVisible();
  }

  async getVisibleDetailSections(): Promise<string[]> {
    const sectionHeaders = this.page.locator(".detail-field h2, .detail-field .label");
    const count = await sectionHeaders.count();
    const sections: string[] = [];
    for (let i = 0; i < count; i++) {
      sections.push(await sectionHeaders.nth(i).innerText());
    }
    return sections;
  }
}
